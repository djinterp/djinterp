/******************************************************************************
* djinterp [test]                                           ssize64_tests_sa.h
*
* This is a test file for `ssize64.h` unit tests.
* For the file itself, go to `\inc\ssize64.h`.
* Note: this module is required to build DTest, so it uses `test_standalone.h`,
* rather than DTest for unit testing. Any modules that are not dependencies of
* DTest should use DTest for unit tests.
* 
* 
* path:      \test\ssize64_tests_sa.h             
* link:      TBA
* author(s): Samuel 'teer' Neal-Blim                          date: 2025.11.11
******************************************************************************/

#ifndef DJINTERP_TESTING_HEADER_TYPES_
#define DJINTERP_TESTING_HEADER_TYPES_ 1

#include <stdlib.h>
#include "../../inc/c/djinterp.h"
#include "../../inc/c/test/test_standalone.h"
#include "../../inc/c/ssize64.h"


// `ssize64` creation and access tests
bool d_tests_sa_ssize64_creation(struct d_test_counter* _test_info);
bool d_tests_sa_ssize64_access(struct d_test_counter* _test_info);

// `ssize64` arithmetic operation tests
bool d_tests_sa_ssize64_arithmetic_functions(struct d_test_counter* _test_info);
bool d_tests_sa_ssize64_arithmetic_macros(struct d_test_counter* _test_info);

// `ssize64` comparison tests
bool d_tests_sa_ssize64_comparison_ssize64(struct d_test_counter* _test_info);
bool d_tests_sa_ssize64_comparison_other_types(struct d_test_counter* _test_info);

// `ssize64` conversion and validation tests
bool d_tests_sa_ssize64_conversion_functions(struct d_test_counter* _test_info);
bool d_tests_sa_ssize64_validation_functions(struct d_test_counter* _test_info);
bool d_tests_sa_ssize64_edge_cases(struct d_test_counter* _test_info);

#endif	// DJINTERP_TESTING_HEADER_TYPES_