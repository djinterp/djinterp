/******************************************************************************
* djinterp [test]                                            file_tests_open.c
*
*   II. STREAMS (file_open) -- opening, reopening, and closing FILE* streams.
* Success paths exercise the standard fixture and staged siblings; the Annex K
* forms are checked for their clear-the-out-parameter-first contract and their
* errno-style returns; and d_fdopen's descriptor-adoption path is exercised
* only where the backend actually has descriptors.
*
* path:      \tests\djinterp\c\fs\file_tests_open.c
* link:      TBA
* author(s): Samuel 'teer' Neal-Blim                          date: 2026.07.21
******************************************************************************/

#include <errno.h>
#include <stdio.h>
#include <string.h>

#include "file_tests.h"


/******************************************************************************
 * II.a  d_fopen
 *****************************************************************************/

static void
d_fs_tests_open_fopen
(
    dtest_suite* _suite
)
{
    char  path[D_FS_TEST_PATH_BUF];
    FILE* file;
    bool  opened;
    bool  created;

    dtest_block(_suite, "d_fopen");

    d_fs_test_path(path, sizeof(path), D_FS_TEST_FILE);

    dtest_test(_suite, "opens an existing file for reading");
    file   = d_fopen(path, "rb");
    opened = (file != NULL);

    if (file)
    {
        d_fclose(file);
        file = NULL;   // the guards below test this pointer
    }

    D_FS_CHECK(_suite, opened);

    #if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL filename -> NULL, EINVAL");
    errno = 0;
    file  = d_fopen(NULL, "rb");
    D_FS_CHECK(_suite, file == NULL);
    D_FS_CHECK(_suite, errno == EINVAL);
    #endif

    #if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL mode -> NULL, EINVAL");
    errno = 0;
    file  = d_fopen(path, NULL);
    D_FS_CHECK(_suite, file == NULL);
    D_FS_CHECK(_suite, errno == EINVAL);
    #endif

    dtest_test(_suite, "a missing file for reading -> NULL");
    d_fs_test_path(path, sizeof(path), "no_such_fopen_file.txt");
    file = d_fopen(path, "rb");
    D_FS_CHECK(_suite, file == NULL);

    dtest_test(_suite, "creates a file for writing");
    d_fs_test_path(path, sizeof(path), "fopen_created.txt");
    file    = d_fopen(path, "wb");
    created = (file != NULL);

    if (file)
    {
        d_fclose(file);
        file = NULL;   // the guards below test this pointer
    }

    D_FS_CHECK(_suite, created);
    D_FS_CHECK(_suite, d_file_exists(path));

    d_remove(path);
}


/******************************************************************************
 * II.b  d_fopen_s
 *****************************************************************************/

static void
d_fs_tests_open_fopen_s
(
    dtest_suite* _suite
)
{
    char   path[D_FS_TEST_PATH_BUF];
    FILE*  stream;
    int    rc;

    dtest_block(_suite, "d_fopen_s");

    d_fs_test_path(path, sizeof(path), D_FS_TEST_FILE);

    dtest_test(_suite, "success -> 0 and a valid stream");
    stream = NULL;
    rc     = d_fopen_s(&stream, path, "rb");
    D_FS_CHECK(_suite, rc == 0);
    D_FS_CHECK(_suite, stream != NULL);

    if (stream)
    {
        d_fclose(stream);
    }

    #if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL out-parameter -> EINVAL");
    rc = d_fopen_s(NULL, path, "rb");
    D_FS_CHECK(_suite, rc == EINVAL);
    #endif

    #if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL filename clears the stream and returns EINVAL");
    stream = (FILE*)0x1;
    rc     = d_fopen_s(&stream, NULL, "rb");
    D_FS_CHECK(_suite, rc == EINVAL);
    D_FS_CHECK(_suite, stream == NULL);
    #endif

    #if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL mode -> EINVAL");
    stream = NULL;
    rc     = d_fopen_s(&stream, path, NULL);
    D_FS_CHECK(_suite, rc == EINVAL);
    #endif

    dtest_test(_suite, "a missing file -> non-zero and a NULL stream");
    d_fs_test_path(path, sizeof(path), "no_such_fopen_s_file.txt");
    stream = (FILE*)0x1;
    rc     = d_fopen_s(&stream, path, "rb");
    D_FS_CHECK(_suite, rc != 0);
    D_FS_CHECK(_suite, stream == NULL);
}


/******************************************************************************
 * II.c  d_freopen
 *****************************************************************************/

static void
d_fs_tests_open_freopen
(
    dtest_suite* _suite
)
{
    char  first[D_FS_TEST_PATH_BUF];
    char  second[D_FS_TEST_PATH_BUF];
    FILE* file;
    FILE* reopened;
    char  buf[64];
    bool  read_ok;

    dtest_block(_suite, "d_freopen");

    d_fs_test_path(first, sizeof(first), D_FS_TEST_FILE);
    d_fs_test_path(second, sizeof(second), "freopen_target.txt");
    d_fs_test_write(second, "SECOND", 6);

    dtest_test(_suite, "reopens a stream onto another file");
    file     = d_fopen(first, "rb");
    reopened = file ? d_freopen(second, "rb", file) : NULL;
    read_ok  = false;

    if (reopened)
    {
        memset(buf, 0, sizeof(buf));

        if (fread(buf, 1, 6, reopened) == 6)
        {
            read_ok = (memcmp(buf, "SECOND", 6) == 0);
        }

        //   d_freopen REUSES the stream it is handed, so `reopened` and
        // `file` are one handle, not two. Closing it closes both, and the
        // `if (file)` cleanup further down would close it a second time --
        // which is a double free, not a leak. It went unnoticed because the
        // case in between reassigned `file` before the cleanup ran, so the
        // stale pointer was overwritten by luck rather than by design.
        d_fclose(reopened);
        file = NULL;   // `reopened` is asserted below, so it keeps its value
    }
    else if (file)
    {
        d_fclose(file);
        file = NULL;   // the guards below test this pointer
    }

    D_FS_CHECK(_suite, reopened != NULL);
    D_FS_CHECK(_suite, read_ok);

    #if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL mode -> NULL, EINVAL");
    file  = d_fopen(first, "rb");
    errno = 0;
    D_FS_CHECK(_suite, d_freopen(second, NULL, file) == NULL);
    D_FS_CHECK(_suite, errno == EINVAL);
    #endif

    if (file)
    {
        d_fclose(file);
        file = NULL;   // the guards below test this pointer
    }

    #if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL stream -> NULL, EINVAL");
    errno = 0;
    D_FS_CHECK(_suite, d_freopen(second, "rb", NULL) == NULL);
    D_FS_CHECK(_suite, errno == EINVAL);
    #endif

    d_remove(second);
}


/******************************************************************************
 * II.d  d_freopen_s
 *****************************************************************************/

static void
d_fs_tests_open_freopen_s
(
    dtest_suite* _suite
)
{
    char  path[D_FS_TEST_PATH_BUF];
    FILE* file;
    FILE* out;
    int   rc;

    dtest_block(_suite, "d_freopen_s");

    d_fs_test_path(path, sizeof(path), D_FS_TEST_FILE);

    dtest_test(_suite, "success -> 0 and a valid stream");
    file = d_fopen(path, "rb");
    out  = NULL;
    rc   = d_freopen_s(&out, path, "rb", file);
    D_FS_CHECK(_suite, rc == 0);
    D_FS_CHECK(_suite, out != NULL);

    if (out)
    {
        //   Same aliasing as d_freopen above: d_freopen_s reuses the stream it
        // is given, so `out` and `file` are one handle. Closing it closes both.
        d_fclose(out);
        file = NULL;   // `out` is asserted above, so it keeps its value
    }
    else if (file)
    {
        d_fclose(file);
        file = NULL;   // the guards below test this pointer
    }

    #if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL out-parameter -> EINVAL");
    file = d_fopen(path, "rb");
    rc   = d_freopen_s(NULL, path, "rb", file);
    D_FS_CHECK(_suite, rc == EINVAL);
    #endif

    if (file)
    {
        d_fclose(file);
        file = NULL;   // the guards below test this pointer
    }

    #if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL mode -> EINVAL");
    file = d_fopen(path, "rb");
    out  = NULL;
    rc   = d_freopen_s(&out, path, NULL, file);
    D_FS_CHECK(_suite, rc == EINVAL);
    #endif

    if (file)
    {
        d_fclose(file);
        file = NULL;   // the guards below test this pointer
    }

#if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL stream -> EINVAL");
    out = NULL;
    rc  = d_freopen_s(&out, path, "rb", NULL);
    D_FS_CHECK(_suite, rc == EINVAL);
#endif
}


/******************************************************************************
 * II.e  d_fdopen
 *****************************************************************************/

static void
d_fs_tests_open_fdopen
(
    dtest_suite* _suite
)
{
#if !D_FILE_BACKEND_IS_STDC
    char  path[D_FS_TEST_PATH_BUF];
    int   fd;
    FILE* stream;
    bool  wrapped;

    dtest_block(_suite, "d_fdopen");

    d_fs_test_path(path, sizeof(path), D_FS_TEST_FILE);

    dtest_test(_suite, "adopts an open descriptor into a stream");
    fd      = d_open(path, O_RDONLY);
    stream  = (fd >= 0) ? d_fdopen(fd, "rb") : NULL;
    wrapped = (stream != NULL);

    if (stream)
    {
        // closing the stream closes the adopted descriptor
        d_fclose(stream);
    }
    else if (fd >= 0)
    {
        d_close(fd);
    }

    D_FS_CHECK(_suite, wrapped);

    dtest_test(_suite, "negative descriptor -> NULL, EBADF");
    errno = 0;
    D_FS_CHECK(_suite, d_fdopen(-1, "rb") == NULL);
    D_FS_CHECK(_suite, errno == EBADF);

#if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL mode -> NULL, EINVAL");
    fd = d_open(path, O_RDONLY);
    errno = 0;
    D_FS_CHECK(_suite, d_fdopen(fd, NULL) == NULL);
    D_FS_CHECK(_suite, errno == EINVAL);
#endif

    if (fd >= 0)
    {
        d_close(fd);
    }
#else
    dtest_block(_suite, "d_fdopen");

    dtest_test(_suite, "ISO C backend has no descriptors -> NULL, ENOSYS");
    errno = 0;
    D_FS_CHECK(_suite, d_fdopen(0, "rb") == NULL);
    D_FS_CHECK(_suite, errno == ENOSYS);
#endif
}


/******************************************************************************
 * II.f  d_fclose
 *****************************************************************************/

static void
d_fs_tests_open_fclose
(
    dtest_suite* _suite
)
{
    char  path[D_FS_TEST_PATH_BUF];
    FILE* file;
    int   rc;

    dtest_block(_suite, "d_fclose");

    d_fs_test_path(path, sizeof(path), D_FS_TEST_FILE);

    dtest_test(_suite, "closing a valid stream -> 0");
    file = d_fopen(path, "rb");
    rc   = file ? d_fclose(file) : -1;
    D_FS_CHECK(_suite, rc == 0);

    #if D_FILE_VALIDATE_IS_ACTIVE
    dtest_test(_suite, "NULL stream -> EOF, EINVAL");
    errno = 0;
    D_FS_CHECK(_suite, d_fclose(NULL) == EOF);
    D_FS_CHECK(_suite, errno == EINVAL);
    #endif
}


/******************************************************************************
 * SECTION ENTRY POINT
 *****************************************************************************/

void
d_fs_tests_open
(
    dtest_suite* _suite
)
{
    dtest_module(_suite, "II. file_open");

    d_fs_tests_open_fopen(_suite);
    d_fs_tests_open_fopen_s(_suite);
    d_fs_tests_open_freopen(_suite);
    d_fs_tests_open_freopen_s(_suite);
    d_fs_tests_open_fdopen(_suite);
    d_fs_tests_open_fclose(_suite);

    return;
}
