#include "./file_tests_sa.h"

/******************************************************************************
 * XIV.  file_pipe  --  PROCESS PIPES
 *****************************************************************************/

#if D_FILE_PIPE_IS_AVAILABLE

/*
d_tests_file_popen
  Tests d_popen / d_pclose.
  The interesting assertion is the last one: d_pclose returns the CHILD's
status, not a success flag, and a suite that tested `!= 0` for "did it close"
would report every failing command as a broken close.
*/
static struct d_test_object*
d_tests_file_popen
(
    void
)
{
    struct d_test_object* items[D_TEST_FILE_MAX_ASSERTS];
    FILE*                 pipe_stream;
    char                  buf[256];
    int                   status;
    size_t                idx;

    idx = 0;

    pipe_stream = d_popen("echo test", "r");
    items[idx++] = D_ASSERT_NOT_NULL("open", pipe_stream,
                                     "d_popen runs a command");

    if (pipe_stream)
    {
        items[idx++] = D_ASSERT_TRUE("read",
                                     (fgets(buf, sizeof(buf), pipe_stream) != NULL) &&
                                     (strlen(buf) > 0),
                                     "the child's output is readable");
        items[idx++] = D_ASSERT_EQUAL("close_success",
                                      d_pclose(pipe_stream), 0,
                                      "d_pclose reaps; 0 = ran AND succeeded");
    }

    // the trap. 0 means the command ran and succeeded; non-zero usually means
    // it ran and FAILED; only -1 means the wait itself broke. Testing
    // `d_pclose(p) != 0` for "did close work" reports every non-zero exit as
    // a close failure.
    pipe_stream = d_popen("exit 3", "r");

    if (pipe_stream)
    {
        status = d_pclose(pipe_stream);
        items[idx++] = D_ASSERT_TRUE("close_not_our_failure", status != -1,
                                     "a failing command is not a d_pclose failure");
        items[idx++] = D_ASSERT_TRUE("child_status_carried", status != 0,
                                     "d_pclose carries the child's exit status");
    }

    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_NULL("null_command", d_popen(NULL, "r"),
                                 "d_popen rejects a NULL command");
    #endif
    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_NULL("null_mode", d_popen("echo x", NULL),
                                 "d_popen rejects a NULL mode");
    #endif
    items[idx++] = D_ASSERT_NULL("bad_mode", d_popen("echo x", "z"),
                                 "d_popen rejects a mode that is not r or w");
    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_EQUAL("close_null", d_pclose(NULL), -1,
                                  "d_pclose rejects NULL");
    #endif

    return d_tests_file_group("d_popen / d_pclose", items, idx);
}


/*
d_tests_file_pipe_all
  Runs every file_pipe test.
*/
struct d_test_object*
d_tests_file_pipe_all
(
    void
)
{
    struct d_test_object* items[2];
    size_t                idx;

    idx = 0;
    items[idx++] = d_tests_file_popen();

    return d_tests_file_group("XIV. file_pipe", items, idx);
}

#endif  // D_FILE_PIPE_IS_AVAILABLE
