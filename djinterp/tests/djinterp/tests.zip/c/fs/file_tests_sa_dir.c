#include "./file_tests_sa.h"

/******************************************************************************
 * X.  file_dir  --  DIRECTORIES AND RESOLUTION
 *****************************************************************************/

/*
d_tests_file_mkdir
  Tests d_mkdir and d_mkdir_p.
*/
static struct d_test_object*
d_tests_file_mkdir
(
    void
)
{
    struct d_test_object* items[D_TEST_FILE_MAX_ASSERTS];
    char                  dir[D_TEST_FILE_PATH_BUF];
    char                  nested[D_TEST_FILE_PATH_BUF];
    char                  parent[D_TEST_FILE_PATH_BUF];
    char                  file_path[D_TEST_FILE_PATH_BUF];
    char                  under_file[D_TEST_FILE_PATH_BUF];
    size_t                idx;

    idx = 0;
    d_tests_file_path(dir, sizeof(dir), "mkdir_test");
    d_tests_file_path(parent, sizeof(parent), "mkdir_p_parent");
    d_tests_file_child(nested, sizeof(nested), parent, "child");
    d_tests_file_child(nested, sizeof(nested), nested, "grandchild");

    items[idx++] = D_ASSERT_EQUAL("create", d_mkdir(dir, S_IRWXU), 0,
                                  "d_mkdir creates a directory");
    items[idx++] = D_ASSERT_TRUE("is_dir", d_is_dir(dir),
                                 "...and it is one");
    items[idx++] = D_ASSERT_EQUAL("existing", d_mkdir(dir, S_IRWXU), -1,
                                  "d_mkdir refuses an existing directory");
    (void)d_rmdir(dir);
    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_EQUAL("null", d_mkdir(NULL, S_IRWXU), -1,
                                  "d_mkdir rejects NULL");
    #endif

    items[idx++] = D_ASSERT_EQUAL("nested", d_mkdir_p(nested, S_IRWXU), 0,
                                  "d_mkdir_p creates missing parents");
    items[idx++] = D_ASSERT_TRUE("nested_is_dir", d_is_dir(nested),
                                 "...all the way down");

    // "ensure this exists" is satisfied by something that already exists --
    // that IS the difference from mkdir
    items[idx++] = D_ASSERT_EQUAL("existing_ok", d_mkdir_p(nested, S_IRWXU),
                                  0,
                                  "d_mkdir_p succeeds when the path is already there");

    // a redundant separator names no component
    items[idx++] = D_ASSERT_EQUAL("redundant_seps",
                                  d_mkdir_p(nested, S_IRWXU), 0,
                                  "empty components are skipped, not created");

    (void)d_rmdir(nested);
    d_tests_file_child(nested, sizeof(nested), parent, "child");
    (void)d_rmdir(nested);
    (void)d_rmdir(parent);

    // a component that exists and is NOT a directory cannot be brought into
    // existence as one
    d_tests_file_path(file_path, sizeof(file_path), D_TEST_FILE_TEST_FILENAME);
    d_tests_file_child(under_file, sizeof(under_file), file_path, "nope");
    items[idx++] = D_ASSERT_EQUAL("component_is_file",
                                  d_mkdir_p(under_file, S_IRWXU), -1,
                                  "a path through a FILE is ENOTDIR, not created");

    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_EQUAL("null_p", d_mkdir_p(NULL, S_IRWXU), -1,
                                  "d_mkdir_p rejects NULL");
    #endif
    items[idx++] = D_ASSERT_EQUAL("empty_p", d_mkdir_p("", S_IRWXU), -1,
                                  "d_mkdir_p rejects an empty path");

    return d_tests_file_group("d_mkdir / d_mkdir_p", items, idx);
}


/*
d_tests_file_rmdir
  Tests d_rmdir.
*/
static struct d_test_object*
d_tests_file_rmdir
(
    void
)
{
    struct d_test_object* items[D_TEST_FILE_MAX_ASSERTS];
    char                  dir[D_TEST_FILE_PATH_BUF];
    size_t                idx;

    idx = 0;
    d_tests_file_path(dir, sizeof(dir), "rmdir_test");
    (void)d_mkdir(dir, S_IRWXU);

    items[idx++] = D_ASSERT_EQUAL("remove", d_rmdir(dir), 0,
                                  "d_rmdir removes an empty directory");
    items[idx++] = D_ASSERT_FALSE("gone", d_is_dir(dir),
                                  "...and it is gone");
    items[idx++] = D_ASSERT_EQUAL("missing",
                                  d_rmdir("no/such/directory"), -1,
                                  "d_rmdir fails for a missing directory");
    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_EQUAL("null", d_rmdir(NULL), -1,
                                  "d_rmdir rejects NULL");
    #endif

    // the scratch directory holds the fixture, so it is not empty
    items[idx++] = D_ASSERT_EQUAL("non_empty",
                                  d_rmdir(D_TEST_FILE_TEMP_DIR), -1,
                                  "d_rmdir refuses a non-empty directory");

    return d_tests_file_group("d_rmdir", items, idx);
}


/*
d_tests_file_traversal
  Tests d_opendir / d_readdir / d_rewinddir / d_closedir.
*/
static struct d_test_object*
d_tests_file_traversal
(
    void
)
{
    struct d_test_object* items[D_TEST_FILE_MAX_ASSERTS];
    struct d_dir_t*       dir;
    struct d_dirent_t*    entry;
    struct d_dirent_t*    entry2;
    char                  first[D_FILE_NAME_MAX + 1];
    size_t                count;
    size_t                dots;
    bool                  found;
    size_t                idx;

    idx = 0;
    count = 0;
    dots  = 0;
    found = false;

    dir = d_opendir(D_TEST_FILE_TEMP_DIR);
    items[idx++] = D_ASSERT_NOT_NULL("open", dir,
                                     "d_opendir opens a directory");

    if (dir)
    {
        while ((entry = d_readdir(dir)) != NULL)
        {
            ++count;

            if ( (strcmp(entry->d_name, ".") == 0) ||
                 (strcmp(entry->d_name, "..") == 0) )
            {
                ++dots;
            }

            if (strcmp(entry->d_name, D_TEST_FILE_TEST_FILENAME) == 0)
            {
                found = true;

#if D_CFG_IS_ON(D_CFG_FILE_DIR_FILL_TYPE)
                items[idx++] = D_ASSERT_EQUAL("type_reg",
                                              (int)entry->d_type, DT_REG,
                                              "d_type identifies a regular file");
#endif
            }
        }

        items[idx++] = D_ASSERT_TRUE("read", count > 0,
                                     "d_readdir returns entries");
        items[idx++] = D_ASSERT_TRUE("found_fixture", found,
                                     "the fixture is among them");

#if D_CFG_IS_ON(D_CFG_FILE_DIR_SKIP_DOTS)
        items[idx++] = D_ASSERT_EQUAL("dots_hidden", dots, (size_t)0,
                                      "SKIP_DOTS=1 hides . and ..");
#else
        items[idx++] = D_ASSERT_EQUAL("dots_present", dots, (size_t)2,
                                      ". and .. are entries like any other");
#endif

        items[idx++] = D_ASSERT_EQUAL("close", d_closedir(dir), 0,
                                      "d_closedir closes the handle");
    }

    items[idx++] = D_ASSERT_NULL("nonexistent",
                                 d_opendir("no/such/directory"),
                                 "d_opendir fails for a missing directory");
    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_NULL("null_path", d_opendir(NULL),
                                 "d_opendir rejects NULL");
    #endif
    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_NULL("read_null", d_readdir(NULL),
                                 "d_readdir rejects NULL");
    #endif
    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_EQUAL("close_null", d_closedir(NULL), -1,
                                  "d_closedir rejects NULL");
    #endif

    dir = d_opendir(D_TEST_FILE_TEMP_DIR);

    if (dir)
    {
        entry = d_readdir(dir);

        if (entry)
        {
            memcpy(first, entry->d_name, strlen(entry->d_name) + 1);
            (void)d_readdir(dir);

            // d_rewinddir returns int, not void: POSIX cannot fail, but Win32
            // has no rewind and must re-open the search, which can
            items[idx++] = D_ASSERT_EQUAL("rewind", d_rewinddir(dir), 0,
                                          "d_rewinddir reports success");

            entry = d_readdir(dir);
            items[idx++] = D_ASSERT_TRUE("rewind_restarts",
                                         entry &&
                                         strcmp(entry->d_name, first) == 0,
                                         "...and the first entry repeats");
        }

        // the entry belongs to the HANDLE, not to the platform: the same
        // storage is reused, so the pointer is stable and its lifetime is
        // sayable
        entry  = d_readdir(dir);
        entry2 = d_readdir(dir);
        items[idx++] = D_ASSERT_TRUE("entry_storage_is_ours",
                                     (entry == NULL) || (entry == entry2),
                                     "the handle owns the entry it returns");

        (void)d_closedir(dir);
    }

    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_EQUAL("rewind_null", d_rewinddir(NULL), -1,
                                  "d_rewinddir rejects NULL");
    #endif

    return d_tests_file_group(
               D_FILE_DIR_TYPE_IS_FREE ?
                   "traversal (d_type from the kernel)" :
                   "traversal (d_type by stat, or absent)",
               items,
               idx);
}


/*
d_tests_file_cwd
  Tests d_getcwd / d_chdir / d_realpath.
*/
static struct d_test_object*
d_tests_file_cwd
(
    void
)
{
    struct d_test_object* items[D_TEST_FILE_MAX_ASSERTS];
    char                  saved[D_FILE_PATH_MAX];
    char                  buf[D_FILE_PATH_MAX];
    size_t                idx;

    idx = 0;

    items[idx++] = D_ASSERT_NOT_NULL("getcwd",
                                     d_getcwd(saved, sizeof(saved)),
                                     "d_getcwd reports a path");
    items[idx++] = D_ASSERT_TRUE("getcwd_is_dir", d_is_dir(saved),
                                 "...and it is a directory");

    // POSIX getcwd(NULL, 0) allocates; this one does not, because two
    // ownership contracts on one function is one too many
    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_NULL("getcwd_null", d_getcwd(NULL, 100),
                                 "d_getcwd requires a buffer");
    #endif
    items[idx++] = D_ASSERT_NULL("getcwd_zero", d_getcwd(buf, 0),
                                 "d_getcwd rejects a zero size");

    items[idx++] = D_ASSERT_EQUAL("chdir",
                                  d_chdir(D_TEST_FILE_TEMP_DIR), 0,
                                  "d_chdir moves the working directory");
    (void)d_chdir(saved);

    items[idx++] = D_ASSERT_EQUAL("chdir_missing",
                                  d_chdir("no/such/directory"), -1,
                                  "d_chdir fails for a missing directory");
    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_EQUAL("chdir_null", d_chdir(NULL), -1,
                                  "d_chdir rejects NULL");
    #endif

#if (D_INTERNAL_FILE_HAS_REALPATH == 1) || D_CFG_IS_ON(D_CFG_FILE_HAS_WIN32)
    items[idx++] = D_ASSERT_NOT_NULL("realpath",
                                     d_realpath(D_TEST_FILE_TEMP_DIR, buf),
                                     "d_realpath resolves an existing path");
    items[idx++] = D_ASSERT_TRUE("realpath_absolute",
                                 d_path_is_absolute(buf),
                                 "...to an absolute path");

    // unlike d_path_normalize, this must ask the filesystem -- so a path that
    // does not exist cannot be resolved
    items[idx++] = D_ASSERT_NULL("realpath_missing",
                                 d_realpath("no/such/path", buf),
                                 "d_realpath requires every component to exist");
    #if D_FILE_VALIDATE_IS_ACTIVE
    items[idx++] = D_ASSERT_NULL("realpath_null",
                                 d_realpath(NULL, buf),
                                 "d_realpath rejects NULL");
    #endif

    #if (D_INTERNAL_FILE_DIR_REALPATH_ALLOC == 1)
    {
        char* owned;

        owned = d_realpath(D_TEST_FILE_TEMP_DIR, NULL);
        #if D_FILE_VALIDATE_IS_ACTIVE
        items[idx++] = D_ASSERT_NOT_NULL("realpath_alloc", owned,
                                         "d_realpath(p, NULL) allocates");
        #endif

        if (owned)
        {
            free(owned);
        }
    }
    #endif
#endif

    return d_tests_file_group("d_getcwd / d_chdir / d_realpath", items, idx);
}


/*
d_tests_file_dir_all
  Runs every file_dir test.
*/
struct d_test_object*
d_tests_file_dir_all
(
    void
)
{
    struct d_test_object* items[8];
    size_t                idx;

    idx = 0;
    items[idx++] = d_tests_file_mkdir();
    items[idx++] = d_tests_file_rmdir();
    items[idx++] = d_tests_file_traversal();
    items[idx++] = d_tests_file_cwd();

    return d_tests_file_group("X. file_dir", items, idx);
}
